package com.dolbommon.dbmon.login;

public interface LoginDaoImp {

	public LoginVO loginOk(LoginVO vo);
	
}
